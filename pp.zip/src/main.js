
import { createApp } from 'vue'
import App from './App.vue'
import "bootstrap/dist/css/bootstrap.min.css"
import "bootstrap"
import '../public/fontawesome/all.min.css'
import '../public/fontawesome/all.min.js'

createApp(App).mount('#app')
